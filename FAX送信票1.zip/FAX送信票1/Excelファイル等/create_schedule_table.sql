CREATE TABLE IF NOT EXISTS schedule (
	"月" TEXT PRIMARY KEY,
    "日" TEXT,
    "曜日" TEXT,
    "行事" TEXT,
	"会社名1" TEXT
    "会社名2" TEXT
	"会社名3" TEXT
    "会社名4" TEXT
	"会社名5" TEXT
    "会社名6" TEXT
	"会社名7" TEXT
	"会社名8" TEXT
	"会社名9" TEXT	
    "会社名10" TEXT)



