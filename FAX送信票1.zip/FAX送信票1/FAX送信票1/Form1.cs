﻿using System;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace FAX送信票1
{
    public partial class Form1 : Form
    {
        private BindingSource bindingSource1 = new BindingSource();
        private BindingSource bindingSource2 = new BindingSource();

        public Form1()
        {
            InitializeComponent();
            this.Load += new EventHandler(Form1_Load);
            this.Shown += new EventHandler(Form1_Shown); // Shownイベントを追加
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadExcelData();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
           
        }

        private void LoadExcelData()
        {
            string filePath = "C:\\Users\\day50\\Desktop\\JTフォルダー\\設計書_テンプレート\\元データ.xlsx"; // Excelファイルのパスを指定

            Excel.Application xlApp = null;
            Excel.Workbook xlWorkbook = null;
            Excel._Worksheet xlWorksheet = null;
            Excel.Range xlRange = null;

            try
            {
                xlApp = new Excel.Application();
                xlWorkbook = xlApp.Workbooks.Open(filePath);
                xlWorksheet = xlWorkbook.Sheets[1];
                xlRange = xlWorksheet.UsedRange;

                DataTable dataTable = new DataTable();

                // 列を追加
                dataTable.Columns.Add("RowIndex");
                dataTable.Columns.Add("Company"); // Company列を追加

                for (int i = 1; i <= xlRange.Columns.Count; i++)
                {
                    dataTable.Columns.Add("Col" + i);
                }

                for (int i = 1; i <= xlRange.Rows.Count; i++)
                {
                    bool hasValueInRow = false;
                    DataRow row = dataTable.NewRow();
                    row["RowIndex"] = i;

                    for (int j = 1; j <= xlRange.Columns.Count; j++)
                    {
                        var cellValue = xlRange.Cells[i, j].Value2;
                        if (cellValue != null && cellValue.ToString() != "")
                        {
                            row["Col" + j] = cellValue.ToString();
                            hasValueInRow = true;
                        }
                        else
                        {
                            row["Col" + j] = DBNull.Value; // 空のセルにはnullを設定
                        }
                    }
                    if (hasValueInRow)
                    {
                        row["Company"] = xlRange.Cells[i, 1].Value2.ToString(); // 最初の列に企業名を設定
                        dataTable.Rows.Add(row);
                    }
                }

                // DataGridViewにバインド
                bindingSource1.DataSource = dataTable;
                dataGridView1.DataSource = bindingSource1;
                dataGridView1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"エラーが発生しました: {ex.Message}");
            }
            finally
            {
                // Excelオブジェクトの解放
                if (xlRange != null) Marshal.ReleaseComObject(xlRange);
                if (xlWorksheet != null) Marshal.ReleaseComObject(xlWorksheet);
                if (xlWorkbook != null) Marshal.ReleaseComObject(xlWorkbook);
                if (xlApp != null) xlApp.Quit(); Marshal.ReleaseComObject(xlApp);

                xlApp = null;
                xlWorkbook = null;
                xlWorksheet = null;
                xlRange = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        private void buttonExtractAndPivot_Click(object sender, EventArgs e)
        {
            DataTable originalTable = (DataTable)bindingSource1.DataSource;
            DataTable pivotTable = ExtractAndPivotValues(originalTable);

            DataTable groupedTable = GroupDataByCompany(pivotTable);
            GenerateFaxSheets(groupedTable); // 呼び出し

            bindingSource2.DataSource = groupedTable;
            dataGridView2.DataSource = bindingSource2;
            dataGridView2.Refresh();
        }


        private DataTable ExtractAndPivotValues(DataTable originalTable)
        {
            DataTable result = new DataTable();

            // 必要な列を追加します
            result.Columns.Add("Date", typeof(string));
            result.Columns.Add("DayOfWeek", typeof(string));
            result.Columns.Add("Company", typeof(string));
            result.Columns.Add("Value", typeof(string));

            for (int j = 5; j < originalTable.Columns.Count; j++) // Col5以降
            {
                string companyName = originalTable.Rows[0][j].ToString(); // 各列の最初の行にある企業名

                for (int i = 1; i < originalTable.Rows.Count; i++) // 1行目をスキップ
                {
                    if (originalTable.Rows[i][j] != DBNull.Value)
                    {
                        DataRow newRow = result.NewRow();

                        // シリアル値を日付に変換し、日付部分だけを抽出
                        if (double.TryParse(originalTable.Rows[i][2].ToString(), out double serialDateValue))
                        {
                            DateTime dateValue = DateTime.FromOADate(serialDateValue);
                            newRow["Date"] = dateValue.Day.ToString(); // 日付部分のみ抽出
                        }
                        else
                        {
                            newRow["Date"] = originalTable.Rows[i][2].ToString(); // 変換できない場合はそのまま
                        }

                        newRow["DayOfWeek"] = originalTable.Rows[i][3].ToString(); // Col2: 曜日

                        // 曜日が数値として表示される場合、文字列としてフォーマット
                        if (double.TryParse(newRow["DayOfWeek"].ToString(), out double dayOfWeekValue))
                        {
                            newRow["DayOfWeek"] = DateTime.FromOADate(dayOfWeekValue).ToString("ddd"); // 曜日を文字列に変換
                        }

                        newRow["Company"] = companyName; // 企業名
                        newRow["Value"] = originalTable.Rows[i][j].ToString(); // Col5以降の非ヌル値
                        result.Rows.Add(newRow);
                    }
                }
            }

            return result;
        }
         private DataTable GroupDataByCompany(DataTable pivotTable)
        {
            DataTable groupedTable = new DataTable();

            // 必要な列を追加します
            groupedTable.Columns.Add("Company", typeof(string));
            groupedTable.Columns.Add("Date", typeof(string));
            groupedTable.Columns.Add("DayOfWeek", typeof(string));
            groupedTable.Columns.Add("Name", typeof(string));

            var groupedData = pivotTable.AsEnumerable()
                .GroupBy(row => row.Field<string>("Company"));

            foreach (var group in groupedData)
            {
                foreach (var row in group)
                {
                    DataRow newRow = groupedTable.NewRow();
                    newRow["Company"] = group.Key;
                    newRow["Date"] = row["Date"];
                    newRow["DayOfWeek"] = row["DayOfWeek"];
                    newRow["Name"] = row["Value"];
                    groupedTable.Rows.Add(newRow);
                }
            }

            return groupedTable;
        }

        private void GenerateFaxSheets(DataTable groupedTable)
        {
            foreach (var companyName in groupedTable.AsEnumerable().Select(row => row.Field<string>("Company")).Distinct())
            {
                DataTable companyTable = groupedTable.AsEnumerable()
                    .Where(row => row.Field<string>("Company") == companyName)
                    .CopyToDataTable();

                GenerateFaxSheetForSelectedCompany(companyName, companyTable);
            }
        }
        
        private void GenerateFaxSheetForSelectedCompany(string companyName, DataTable companyTable)
        {
            string templatePath = "C:\\Users\\day50\\Desktop\\JTフォルダー\\設計書_テンプレート\\FAX原紙.xlsx"; // FAX原紙のパスを指定
            string outputPath = $"C:\\Users\\day50\\Desktop\\JTフォルダー\\設計書_テンプレート\\FAX_{companyName}.xlsx"; // 保存するファイル名

            Excel.Application xlApp = new Excel.Application();
            xlApp.DisplayAlerts = false; // 上書き確認のダイアログを表示しないように設定
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(templatePath);
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];

            // 選択された企業名を指定セルに貼り付ける
            xlWorksheet.Cells[7, 1].Value = companyName; // A7セルに企業名を貼り付ける
            xlWorksheet.Cells[5, 2].Value = companyName; // B5セルに企業名を貼り付ける

            int rowIndex =21; // C列のデータを開始する行（適宜調整）

            foreach (DataRow row in companyTable.Rows)
            {
                xlWorksheet.Cells[rowIndex, 3].Value = row["Date"];
                xlWorksheet.Cells[rowIndex, 5].Value = row["DayOfWeek"];
                xlWorksheet.Cells[rowIndex, 7].Value = row["Name"];
                rowIndex++;
            }
            // DataGridViewの2行目2列目の値を取得
            var cellValue = dataGridView1.Rows[1].Cells[1].Value;

            // ExcelのB19に値を入力
            xlWorksheet.Cells[19, 2].Value = cellValue;

            xlWorkbook.SaveAs(outputPath); // 保存するファイル名
            xlWorkbook.Close();
            xlApp.Quit();

            Marshal.ReleaseComObject(xlWorksheet);
            Marshal.ReleaseComObject(xlWorkbook);
            Marshal.ReleaseComObject(xlApp);

            // アプリケーション全体を終了
            Application.Exit();
        }
    }
}